// Zheen H. Suseyi
// 09/27/24
// Checkpoint 9

/*
 Your challenge is this: write a function that accepts an optional array of integers, and returns one randomly. If the array is missing or empty, return a random number in the range 1 through 100.

 If that sounds easy, it’s because I haven’t explained the catch yet: I want you to write your function in a single line of code. No, that doesn’t mean you should just write lots of code then remove all the line breaks – you should be able to write this whole thing in one line of code.
 
// ORIGINAL CODE NOT IN ONE LINE

import UIKit

func randomInt(arr: [Int]?) -> [Int] {
    var random = Int.random(in: 1...100)
    var randomArr: [Int] = []
    guard let arr = arr else {
        randomArr.append(random)
        return randomArr
    }
    return arr
}
let newArray = randomInt(arr: nil)
print(newArray)
 */

// New code in one line
import UIKit
// Our function
func randomInt(from arr: [Int]?) -> Int? {
    // if Arr exists, print a random element from the array, otherwise print a random number from 1-100
    arr?.randomElement() ?? Int.random(in: 1...100)
}
randomInt(from: nil)

